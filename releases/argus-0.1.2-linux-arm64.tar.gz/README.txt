Argus Sentinel 0.1.2 — Linux arm64 binary

What's new in 0.1.2
-------------------
- Console single-host UX collapse (F-R4-66 chunks 1-5) — hides
  fleet-only UI (Host columns, "All Hosts" filter chips, per-host
  band headers, role chip, fleet welcome card) on desktop installs.
- macOS .pkg now ships /Applications/Argus.app launcher.
- Windows .msi now installs argus-sentinel.exe + registers it as
  the ArgusSentinelProbe service so "AI Tools on this Device"
  populates within 30 seconds of install.

Run:
  ./argus-desktop -db ~/.local/share/argus/argus.db

Then open http://127.0.0.1:3000 in your browser for the Console.
