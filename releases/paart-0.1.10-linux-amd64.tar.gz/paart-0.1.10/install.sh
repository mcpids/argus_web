#!/usr/bin/env bash
# Paart Linux installer (portable tarball edition).
#
# Installs the single-host desktop product as two systemd *system*
# services running as root:
#   argus-desktop   — control plane + web Console on http://localhost:3000
#   argus-sentinel  — endpoint probe that discovers AI-tool processes
#
# Usage:  sudo ./install.sh
#
# For Debian/Ubuntu the .deb is preferred (apt handles upgrades +
# conffiles); this script is the distro-agnostic fallback.
set -euo pipefail

PREFIX_BIN=/usr/bin
UNIT_DIR=/lib/systemd/system
CONF_DIR=/etc/argus
HERE="$(cd "$(dirname "$0")" && pwd)"

if [ "$(id -u)" -ne 0 ]; then
    echo "argus: install must run as root — re-run with:  sudo ./install.sh" >&2
    exit 1
fi

if ! command -v systemctl >/dev/null 2>&1; then
    echo "argus: systemd (systemctl) not found — this installer targets systemd distros." >&2
    echo "       You can still run the binaries directly: $HERE/bin/argus-desktop" >&2
    exit 1
fi

echo "argus: installing binaries to $PREFIX_BIN"
install -m 0755 "$HERE/bin/argus-desktop"  "$PREFIX_BIN/argus-desktop"
install -m 0755 "$HERE/bin/argus-sentinel" "$PREFIX_BIN/argus-sentinel"

echo "argus: installing config to $CONF_DIR"
install -d -m 0755 "$CONF_DIR"
if [ -f "$CONF_DIR/sentinel.yaml" ]; then
    echo "argus: $CONF_DIR/sentinel.yaml already exists — leaving your copy untouched"
else
    install -m 0644 "$HERE/etc/argus/sentinel.yaml" "$CONF_DIR/sentinel.yaml"
fi

echo "argus: installing systemd units to $UNIT_DIR"
install -m 0644 "$HERE/systemd/argus-desktop.service"  "$UNIT_DIR/argus-desktop.service"
install -m 0644 "$HERE/systemd/argus-sentinel.service" "$UNIT_DIR/argus-sentinel.service"

echo "argus: enabling + starting services"
systemctl daemon-reload
systemctl enable --now argus-desktop.service argus-sentinel.service

echo
echo "argus: installed."
echo "  Console:    http://localhost:3000"
echo "  Status:     systemctl status argus-desktop argus-sentinel"
echo "  Logs:       journalctl -u argus-desktop -u argus-sentinel -f"
echo "  Uninstall:  sudo ./uninstall.sh"
