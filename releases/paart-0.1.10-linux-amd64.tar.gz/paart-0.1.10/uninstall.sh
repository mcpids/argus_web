#!/usr/bin/env bash
# Paart Linux uninstaller (portable tarball edition).
# Removes the binaries + systemd units. Config and data are kept unless
# you remove them explicitly (the script prints the paths).
#
# Usage:  sudo ./uninstall.sh
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
    echo "argus: uninstall must run as root — re-run with:  sudo ./uninstall.sh" >&2
    exit 1
fi

echo "argus: stopping + disabling services"
systemctl disable --now argus-sentinel.service argus-desktop.service 2>/dev/null || true

echo "argus: removing systemd units"
rm -f /lib/systemd/system/argus-desktop.service /lib/systemd/system/argus-sentinel.service
systemctl daemon-reload 2>/dev/null || true

echo "argus: removing binaries"
rm -f /usr/bin/argus-desktop /usr/bin/argus-sentinel

echo
echo "argus: removed binaries + units."
echo "  Config and data were kept. To remove them too:"
echo "    sudo rm -rf /etc/argus /var/lib/argus /var/lib/argus-sentinel"
