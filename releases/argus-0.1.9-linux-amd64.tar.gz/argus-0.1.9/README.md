# Linux packaging

Ships the single-host **desktop** edition of Argus for Linux as two
systemd **system** services running as root:

| Service | What | Listens |
|---|---|---|
| `argus-desktop` | Control plane + REST API + embedded web Console | `127.0.0.1:3000` (Console), `127.0.0.1:9090` (gRPC) |
| `argus-sentinel` | Endpoint probe — walks `/proc`, discovers AI-tool processes, reports to the control plane | — |

Installed layout:

| Path | What |
|---|---|
| `/usr/bin/argus-desktop`, `/usr/bin/argus-sentinel` | Static, pure-Go binaries (no glibc/CGO dependency) |
| `/lib/systemd/system/argus-{desktop,sentinel}.service` | systemd units |
| `/etc/argus/sentinel.yaml` | Sentinel config (a dpkg conffile — your edits survive upgrades) |
| `/var/lib/argus/argus.db` | SQLite data (created on first boot via `StateDirectory=`) |
| `/var/lib/argus-sentinel/host.json` | Stable per-host id (created on first boot) |

The user opens **http://localhost:3000** and sees the Console; the
**AI Tools** page lists processes the Sentinel discovered.

> **Why root system services (not per-user, as on macOS)?** Running as
> root lets the probe read `/proc/<pid>/exe` for *every* process — full
> AI-tool visibility regardless of which user launched them — and gives
> a clean `systemctl enable --now` install that works headless and at
> boot, matching the Windows service model.

## Why two formats

- **`.deb`** — Debian/Ubuntu. `apt`/`dpkg` handles enable-on-install,
  upgrades, and conffile preservation.
- **tarball + `install.sh`** — every other systemd distro (Fedora,
  Arch, openSUSE, …). Same layout, same units; the script does what the
  `.deb` maintainer scripts do.

## Building

Pure-Go cross-compile — build either artifact for any arch from any host.

```bash
# Portable tarball (works on any build host — just tar):
make desktop-tarball-linux-amd64      # -> bin/desktop/linux-amd64/argus-<ver>-linux-amd64.tar.gz
make desktop-tarball-linux-arm64

# .deb (needs dpkg-deb — run on a Debian/Ubuntu host or in CI):
make desktop-deb-linux-amd64          # -> bin/desktop/linux-amd64/argus_<ver>_amd64.deb
make desktop-deb-linux-arm64
```

Both targets transitively run `console-embed` + `desktop-build-linux-<arch>`
(which builds **both** `argus-desktop` and `argus-sentinel`).

## Installing

```bash
# Debian/Ubuntu:
sudo apt install ./argus_<ver>_<arch>.deb     # or: sudo dpkg -i ...

# Other distros:
tar xzf argus-<ver>-linux-<arch>.tar.gz
cd argus-<ver>
sudo ./install.sh
```

Both enable + start the services immediately and at boot.

## Verifying

```bash
systemctl status argus-desktop argus-sentinel
curl -s http://localhost:3000/healthz                       # {"status":"ok"}
curl -s "http://localhost:3000/api/v1/agents/endpoints?tenant_id=00000000-0000-0000-0000-000000000001"
journalctl -u argus-sentinel -f                             # watch the probe report
```

## Uninstalling

```bash
sudo apt remove argus            # or: sudo ./uninstall.sh   (tarball)
sudo apt purge  argus            # also wipes /var/lib/argus* and /etc/argus
```
