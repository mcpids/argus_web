Argus Sentinel 0.1.9 — Linux binary

What's new in 0.1.9
-------------------
- The Console shows this device as actively monitored even before any AI
  tool is detected — a healthy daemon no longer reads as "Down".
- Daemon logs are written to a file for diagnosability.
- Single-binary desktop app: embedded Console + local SQLite.

Run:
  ./argus-desktop -db ~/.local/share/argus/argus.db
Then open http://127.0.0.1:3000 in your browser for the Console.
