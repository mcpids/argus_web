Argus Sentinel 0.1.4 — Linux amd64 binary

What's new in 0.1.4
-------------------
- Console Settings → "Demo mode" toggle (replaces the
  ARGUS_DEMO_MODE env-var dance v0.1.3 required).
- /api/v1/settings/demo-mode GET/POST endpoints persist the
  toggle to a new SQLite settings table.
- /healthz remains CORS-open so demo.cognifinity.lu can probe a
  default install.

Run:
  ./argus-desktop -db ~/.local/share/argus/argus.db

Then open http://127.0.0.1:3000 in your browser for the Console.
