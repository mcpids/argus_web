Argus Sentinel 0.1.7 — Linux binary

What's new in 0.1.7
-------------------
- Windows endpoint probe: closes the v0.1.6 detection gap so
  ChatGPT.exe et al. actually surface in the Console (gRPC +
  storage validators + SQL CHECK now accept host_os="windows").
  Linux + macOS users not affected by this fix.
- Microsoft Copilot + GitHub Copilot detection patterns added
  (covers M365Copilot.exe, Microsoft.Copilot AppX, github-copilot-cli,
  gh-copilot, and the VS Code extension).
- Replaced placeholder dark-stone .app/.msi icons with the actual
  Argus brand mark (teal hexagonal eye) — macOS Dock/Launchpad
  and Windows tray/Start menu now show the real glyph.
- Bumped Platform Info "Version" surface from a stale 0.1.0 to
  0.1.7 across daemon + Console Settings + installer metadata.

Run:
  ./argus-desktop -db ~/.local/share/argus/argus.db

Then open http://127.0.0.1:3000 in your browser for the Console.
