Argus Sentinel 0.1.8 — Linux binary

What's new in 0.1.8
-------------------
- Single-binary desktop app: the Console and database are embedded
  (local SQLite), so there are no external services to run.
- Optional anonymous usage heartbeat — OFF by default. Enable it in
  Settings to share install count + version; nothing leaves your
  machine unless you opt in. See PRIVACY.md.

Run:
  ./argus-desktop -db ~/.local/share/argus/argus.db

Then open http://127.0.0.1:3000 in your browser for the Console.
