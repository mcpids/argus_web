Argus Sentinel 0.1.3 — Linux arm64 binary

What's new in 0.1.3
-------------------
- macOS .pkg now opens a native WKWebView window (was: browser tab).
- /healthz endpoint now responds CORS-open so demo.cognifinity.lu
  can detect a default install.
- argus-desktop wipes stale demo-tenant rows on boot when demo
  mode is OFF, clearing leftover scenario data from prior installs.

Run:
  ./argus-desktop -db ~/.local/share/argus/argus.db

Then open http://127.0.0.1:3000 in your browser for the Console.
