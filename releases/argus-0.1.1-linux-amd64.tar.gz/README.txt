Argus Sentinel 0.1.1 — Linux amd64 binary

What's new in 0.1.1
-------------------
Console refactor (F-R4-66): single-host installs now hide fleet-only
UI surfaces — Host columns, "All Hosts / macOS / Linux" filter rows,
fleet-tagged KPI tiles, per-host group bands, "across N hosts"
suffixes. The Console auto-detects single vs fleet from your tenant
shape; override with VITE_ARGUS_UI_MODE=fleet at build time.

Run:
  ./argus-desktop -db ~/.local/share/argus/argus.db

Then open http://127.0.0.1:3000 in your browser for the Console.

To run as a systemd service, see
https://github.com/mcpids/argus/blob/main/packaging/linux/README.md
(packaging coming with v0.2.0).
