Argus Sentinel 0.1.0 — Linux arm64 binary

Run:
  ./argus-desktop -db ~/.local/share/argus/argus.db

Then open http://127.0.0.1:3000 in your browser for the Console.

To run as a systemd service, see
https://github.com/mcpids/argus/blob/main/packaging/linux/README.md
(packaging coming with v0.2.0).
