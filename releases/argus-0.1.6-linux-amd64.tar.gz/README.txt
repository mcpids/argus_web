Argus Sentinel 0.1.6 — Linux binary

What's new in 0.1.6
-------------------
- Windows endpoint probe now detects ChatGPT.exe, Cursor.exe,
  Claude.exe, codex.exe, ollama.exe, etc. (Linux + macOS already
  had this; Windows was a stub. Linux users not affected.)
- DemoBanner: solid warm-sand colour + in-flow positioning so it
  no longer overlaps the page hero.
- Drop "S.à r.l-S" legal-form suffix from copyright lines and
  installer metadata. Use "Cognifinity" everywhere.

Run:
  ./argus-desktop -db ~/.local/share/argus/argus.db

Then open http://127.0.0.1:3000 in your browser for the Console.
